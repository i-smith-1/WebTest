import type { User, Session } from '@supabase/supabase-js';

export interface AuthState {
  user: User | null;
  session: Session | null;
  loading: boolean;
}

export interface ContentGenerationInput {
  niche: string;
  goal: string;
  tone: string;
  postType: string;
  generateImage?: boolean;
  generateVideo?: boolean;
}

export interface GeneratedContentResult {
  caption: string;
  hashtags: string;
  imagePrompt: string;
  imageUrl?: string;
  videoUrl?: string;
  mediaType?: string;
}

export interface ScheduledPostWithContent {
  id: string;
  user_id: string;
  content_id: string;
  scheduled_date: string;
  scheduled_time: string;
  status: string;
  created_at: string;
  updated_at: string;
  generated_content: {
    id: string;
    caption: string;
    hashtags: string;
    image_prompt: string;
    image_url: string;
    video_url: string;
    media_type: string;
    niche: string;
    goal: string;
    tone: string;
    post_type: string;
    created_at: string;
  };
}
