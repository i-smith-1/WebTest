export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      generated_content: {
        Row: {
          id: string;
          user_id: string;
          niche: string;
          goal: string;
          tone: string;
          post_type: string;
          caption: string;
          hashtags: string;
          image_prompt: string;
          image_url: string;
          video_url: string;
          media_type: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          niche: string;
          goal: string;
          tone: string;
          post_type: string;
          caption: string;
          hashtags: string;
          image_prompt: string;
          image_url?: string;
          video_url?: string;
          media_type?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          niche?: string;
          goal?: string;
          tone?: string;
          post_type?: string;
          caption?: string;
          hashtags?: string;
          image_prompt?: string;
          image_url?: string;
          video_url?: string;
          media_type?: string;
          created_at?: string;
        };
      };
      scheduled_posts: {
        Row: {
          id: string;
          user_id: string;
          content_id: string;
          scheduled_date: string;
          scheduled_time: string;
          status: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          content_id: string;
          scheduled_date: string;
          scheduled_time?: string;
          status?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          content_id?: string;
          scheduled_date?: string;
          scheduled_time?: string;
          status?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
}

export type Profile = Database['public']['Tables']['profiles']['Row'];
export type GeneratedContent = Database['public']['Tables']['generated_content']['Row'];
export type ScheduledPost = Database['public']['Tables']['scheduled_posts']['Row'];
