import { supabase } from '../lib/supabase';
import type { GeneratedContent } from '../types/database';
import type { ContentGenerationInput, GeneratedContentResult } from '../types';

export async function generateContent(input: ContentGenerationInput): Promise<GeneratedContentResult> {
  const { data, error } = await supabase.functions.invoke('generate-instagram-content', {
    body: input,
  });

  if (error) {
    throw new Error(error.message || 'Failed to generate content');
  }

  return data as GeneratedContentResult;
}

export async function saveGeneratedContent(
  userId: string,
  input: ContentGenerationInput,
  result: GeneratedContentResult
): Promise<GeneratedContent> {
  const { data, error } = await supabase
    .from('generated_content')
    .insert({
      user_id: userId,
      niche: input.niche,
      goal: input.goal,
      tone: input.tone,
      post_type: input.postType,
      caption: result.caption,
      hashtags: result.hashtags,
      image_prompt: result.imagePrompt,
      image_url: result.imageUrl || '',
      video_url: result.videoUrl || '',
      media_type: result.mediaType || 'none',
    })
    .select()
    .single();

  if (error) {
    throw new Error(error.message);
  }

  return data;
}

export async function getUserContent(userId: string): Promise<GeneratedContent[]> {
  const { data, error } = await supabase
    .from('generated_content')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) {
    throw new Error(error.message);
  }

  return data || [];
}

export async function deleteContent(contentId: string): Promise<void> {
  const { error } = await supabase
    .from('generated_content')
    .delete()
    .eq('id', contentId);

  if (error) {
    throw new Error(error.message);
  }
}
