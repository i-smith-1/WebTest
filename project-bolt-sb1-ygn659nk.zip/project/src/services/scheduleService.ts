import { supabase } from '../lib/supabase';
import type { ScheduledPost } from '../types/database';
import type { ScheduledPostWithContent } from '../types';

export async function schedulePost(
  userId: string,
  contentId: string,
  scheduledDate: string,
  scheduledTime: string
): Promise<ScheduledPost> {
  const { data, error } = await supabase
    .from('scheduled_posts')
    .insert({
      user_id: userId,
      content_id: contentId,
      scheduled_date: scheduledDate,
      scheduled_time: scheduledTime,
      status: 'pending',
    })
    .select()
    .single();

  if (error) {
    throw new Error(error.message);
  }

  return data;
}

export async function getUserScheduledPosts(userId: string): Promise<ScheduledPostWithContent[]> {
  const { data, error } = await supabase
    .from('scheduled_posts')
    .select(`
      *,
      generated_content (
        id,
        caption,
        hashtags,
        image_prompt,
        image_url,
        video_url,
        media_type,
        niche,
        goal,
        tone,
        post_type,
        created_at
      )
    `)
    .eq('user_id', userId)
    .order('scheduled_date', { ascending: true });

  if (error) {
    throw new Error(error.message);
  }

  return (data || []) as ScheduledPostWithContent[];
}

export async function updateScheduledPost(
  postId: string,
  updates: {
    scheduled_date?: string;
    scheduled_time?: string;
    status?: string;
  }
): Promise<ScheduledPost> {
  const { data, error } = await supabase
    .from('scheduled_posts')
    .update(updates)
    .eq('id', postId)
    .select()
    .single();

  if (error) {
    throw new Error(error.message);
  }

  return data;
}

export async function deleteScheduledPost(postId: string): Promise<void> {
  const { error } = await supabase
    .from('scheduled_posts')
    .delete()
    .eq('id', postId);

  if (error) {
    throw new Error(error.message);
  }
}
