import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Layout } from '../components/Layout';
import {
  Calendar,
  Clock,
  Loader2,
  Trash2,
  Edit2,
  X,
  ChevronLeft,
  ChevronRight,
  Plus,
  AlertCircle,
  CheckCircle
} from 'lucide-react';
import { getUserContent } from '../services/contentService';
import {
  getUserScheduledPosts,
  schedulePost,
  updateScheduledPost,
  deleteScheduledPost
} from '../services/scheduleService';
import type { GeneratedContent } from '../types/database';
import type { ScheduledPostWithContent } from '../types';

export function Schedule() {
  const { user } = useAuth();
  const [scheduledPosts, setScheduledPosts] = useState<ScheduledPostWithContent[]>([]);
  const [availableContent, setAvailableContent] = useState<GeneratedContent[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingPost, setEditingPost] = useState<ScheduledPostWithContent | null>(null);
  const [selectedContentId, setSelectedContentId] = useState('');
  const [selectedTime, setSelectedTime] = useState('09:00');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    try {
      const [postsData, contentData] = await Promise.all([
        getUserScheduledPosts(user.id),
        getUserContent(user.id),
      ]);
      setScheduledPosts(postsData);
      setAvailableContent(contentData);
    } catch (err) {
      console.error('Error loading data:', err);
    } finally {
      setLoading(false);
    }
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();
    return { daysInMonth, startingDay };
  };

  const getPostsForDate = (date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    return scheduledPosts.filter((p) => p.scheduled_date === dateStr);
  };

  const handlePreviousMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));
  };

  const handleDateClick = (day: number) => {
    const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
    setSelectedDate(date);
    setShowScheduleModal(true);
  };

  const handleSchedulePost = async () => {
    if (!user || !selectedDate || !selectedContentId) {
      setError('Please select content to schedule');
      return;
    }

    setSubmitting(true);
    setError('');
    try {
      await schedulePost(
        user.id,
        selectedContentId,
        selectedDate.toISOString().split('T')[0],
        selectedTime
      );
      await loadData();
      setShowScheduleModal(false);
      setSelectedContentId('');
      setSelectedTime('09:00');
      setSuccess('Post scheduled successfully!');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to schedule post');
    } finally {
      setSubmitting(false);
    }
  };

  const handleEditPost = (post: ScheduledPostWithContent) => {
    setEditingPost(post);
    setSelectedTime(post.scheduled_time.substring(0, 5));
    setShowEditModal(true);
  };

  const handleUpdatePost = async () => {
    if (!editingPost) return;

    setSubmitting(true);
    setError('');
    try {
      await updateScheduledPost(editingPost.id, {
        scheduled_time: selectedTime,
      });
      await loadData();
      setShowEditModal(false);
      setEditingPost(null);
      setSuccess('Post updated successfully!');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update post');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeletePost = async (postId: string) => {
    if (!confirm('Are you sure you want to delete this scheduled post?')) return;

    try {
      await deleteScheduledPost(postId);
      await loadData();
      setSuccess('Post deleted successfully!');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete post');
    }
  };

  const { daysInMonth, startingDay } = getDaysInMonth(currentMonth);
  const today = new Date();

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="w-8 h-8 animate-spin text-teal-600" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Content Schedule</h1>
          <p className="text-gray-500">Plan and manage your Instagram posts.</p>
        </div>

        {success && (
          <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-100 rounded-xl text-green-700 text-sm mb-6">
            <CheckCircle className="w-5 h-5 flex-shrink-0" />
            <span>{success}</span>
          </div>
        )}

        {error && !showScheduleModal && !showEditModal && (
          <div className="flex items-center gap-3 p-4 bg-red-50 border border-red-100 rounded-xl text-red-700 text-sm mb-6">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
              <div className="flex items-center justify-between p-4 border-b border-gray-100">
                <button
                  onClick={handlePreviousMonth}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <ChevronLeft className="w-5 h-5 text-gray-600" />
                </button>
                <h2 className="text-lg font-semibold text-gray-900">
                  {currentMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                </h2>
                <button
                  onClick={handleNextMonth}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <ChevronRight className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="grid grid-cols-7 border-b border-gray-100">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                  <div key={day} className="p-3 text-center text-sm font-medium text-gray-500">
                    {day}
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-7">
                {Array.from({ length: startingDay }).map((_, i) => (
                  <div key={`empty-${i}`} className="p-2 min-h-[100px] border-b border-r border-gray-100 bg-gray-50" />
                ))}
                {Array.from({ length: daysInMonth }).map((_, i) => {
                  const day = i + 1;
                  const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
                  const posts = getPostsForDate(date);
                  const isToday =
                    date.toDateString() === today.toDateString();
                  const isPast = date < new Date(today.getFullYear(), today.getMonth(), today.getDate());

                  return (
                    <div
                      key={day}
                      onClick={() => !isPast && handleDateClick(day)}
                      className={`p-2 min-h-[100px] border-b border-r border-gray-100 transition-colors ${
                        isPast ? 'bg-gray-50 cursor-not-allowed' : 'hover:bg-teal-50 cursor-pointer'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span
                          className={`text-sm font-medium ${
                            isToday
                              ? 'w-7 h-7 bg-teal-600 text-white rounded-full flex items-center justify-center'
                              : isPast
                              ? 'text-gray-400'
                              : 'text-gray-700'
                          }`}
                        >
                          {day}
                        </span>
                        {!isPast && (
                          <Plus className="w-4 h-4 text-gray-300 hover:text-teal-600" />
                        )}
                      </div>
                      <div className="space-y-1">
                        {posts.slice(0, 2).map((post) => (
                          <div
                            key={post.id}
                            className="text-xs bg-teal-100 text-teal-700 rounded px-2 py-1 truncate"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEditPost(post);
                            }}
                          >
                            {post.scheduled_time.substring(0, 5)} - {post.generated_content.post_type}
                          </div>
                        ))}
                        {posts.length > 2 && (
                          <div className="text-xs text-gray-500">+{posts.length - 2} more</div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-2xl border border-gray-100 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Upcoming Posts</h3>
              <div className="space-y-4">
                {scheduledPosts.filter((p) => p.status === 'pending').length === 0 ? (
                  <div className="text-center py-8">
                    <Calendar className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                    <p className="text-sm text-gray-500">No upcoming posts</p>
                  </div>
                ) : (
                  scheduledPosts
                    .filter((p) => p.status === 'pending')
                    .slice(0, 5)
                    .map((post) => (
                      <div
                        key={post.id}
                        className="p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-teal-600" />
                            <span className="text-sm font-medium text-gray-900">
                              {new Date(post.scheduled_date).toLocaleDateString('en-US', {
                                month: 'short',
                                day: 'numeric',
                              })}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleEditPost(post)}
                              className="p-1 text-gray-400 hover:text-teal-600 transition-colors"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeletePost(post.id)}
                              className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                        {post.generated_content.image_url && (
                          <img
                            src={post.generated_content.image_url}
                            alt="Post preview"
                            className="w-full h-32 object-cover rounded-lg mb-2"
                          />
                        )}
                        <div className="flex items-center gap-2 text-xs text-gray-500 mb-2">
                          <Clock className="w-3 h-3" />
                          {post.scheduled_time.substring(0, 5)}
                          <span className="px-2 py-0.5 bg-white rounded-full">
                            {post.generated_content.post_type}
                          </span>
                        </div>
                        <p className="text-xs text-gray-600 line-clamp-2">
                          {post.generated_content.caption.substring(0, 80)}...
                        </p>
                      </div>
                    ))
                )}
              </div>
            </div>

            <div className="bg-gradient-to-br from-teal-500 to-cyan-600 rounded-2xl p-6 text-white">
              <h3 className="font-semibold mb-2">Pro Tip</h3>
              <p className="text-sm text-teal-100">
                Best engagement times on Instagram are typically 11am-1pm and 7pm-9pm. Schedule
                your content during these windows for maximum reach!
              </p>
            </div>
          </div>
        </div>

        {showScheduleModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl w-full max-w-md p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Schedule Post</h3>
                <button
                  onClick={() => {
                    setShowScheduleModal(false);
                    setError('');
                  }}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>

              {error && (
                <div className="flex items-center gap-3 p-4 bg-red-50 border border-red-100 rounded-xl text-red-700 text-sm mb-4">
                  <AlertCircle className="w-5 h-5 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Date</label>
                  <div className="px-4 py-3 bg-gray-50 rounded-xl text-gray-700">
                    {selectedDate?.toLocaleDateString('en-US', {
                      weekday: 'long',
                      month: 'long',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Time</label>
                  <input
                    type="time"
                    value={selectedTime}
                    onChange={(e) => setSelectedTime(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Select Content
                  </label>
                  {availableContent.length === 0 ? (
                    <p className="text-sm text-gray-500">
                      No content available. Create some content first!
                    </p>
                  ) : (
                    <div className="space-y-3 max-h-64 overflow-y-auto">
                      {availableContent.map((content) => (
                        <div
                          key={content.id}
                          onClick={() => setSelectedContentId(content.id)}
                          className={`p-3 border-2 rounded-xl cursor-pointer transition-all ${
                            selectedContentId === content.id
                              ? 'border-teal-500 bg-teal-50'
                              : 'border-gray-200 hover:border-gray-300 bg-white'
                          }`}
                        >
                          <div className="flex gap-3">
                            {content.image_url && (
                              <img
                                src={content.image_url}
                                alt="Content preview"
                                className="w-16 h-16 object-cover rounded-lg flex-shrink-0"
                              />
                            )}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-xs font-medium text-teal-600 bg-teal-100 px-2 py-0.5 rounded-full">
                                  {content.post_type}
                                </span>
                                {content.image_url && (
                                  <span className="text-xs text-gray-500">📷 Image</span>
                                )}
                              </div>
                              <p className="text-sm text-gray-700 line-clamp-2">
                                {content.caption.substring(0, 60)}...
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    onClick={() => {
                      setShowScheduleModal(false);
                      setError('');
                    }}
                    className="flex-1 py-3 bg-gray-100 text-gray-700 font-medium rounded-xl hover:bg-gray-200 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSchedulePost}
                    disabled={submitting || !selectedContentId}
                    className="flex-1 py-3 bg-teal-600 text-white font-medium rounded-xl hover:bg-teal-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Scheduling...
                      </>
                    ) : (
                      'Schedule'
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {showEditModal && editingPost && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl w-full max-w-md p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Edit Scheduled Post</h3>
                <button
                  onClick={() => {
                    setShowEditModal(false);
                    setEditingPost(null);
                    setError('');
                  }}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>

              {error && (
                <div className="flex items-center gap-3 p-4 bg-red-50 border border-red-100 rounded-xl text-red-700 text-sm mb-4">
                  <AlertCircle className="w-5 h-5 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Date</label>
                  <div className="px-4 py-3 bg-gray-50 rounded-xl text-gray-700">
                    {new Date(editingPost.scheduled_date).toLocaleDateString('en-US', {
                      weekday: 'long',
                      month: 'long',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Time</label>
                  <input
                    type="time"
                    value={selectedTime}
                    onChange={(e) => setSelectedTime(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Content</label>
                  <div className="p-4 bg-gray-50 rounded-xl space-y-3">
                    {editingPost.generated_content.image_url && (
                      <img
                        src={editingPost.generated_content.image_url}
                        alt="Content preview"
                        className="w-full h-48 object-cover rounded-lg"
                      />
                    )}
                    <p className="text-sm text-gray-700">
                      {editingPost.generated_content.caption.substring(0, 100)}...
                    </p>
                    <span className="text-xs text-teal-600 bg-teal-50 px-2 py-1 rounded-full">
                      {editingPost.generated_content.post_type}
                    </span>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    onClick={() => {
                      setShowEditModal(false);
                      setEditingPost(null);
                      setError('');
                    }}
                    className="flex-1 py-3 bg-gray-100 text-gray-700 font-medium rounded-xl hover:bg-gray-200 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleUpdatePost}
                    disabled={submitting}
                    className="flex-1 py-3 bg-teal-600 text-white font-medium rounded-xl hover:bg-teal-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Updating...
                      </>
                    ) : (
                      'Update'
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
