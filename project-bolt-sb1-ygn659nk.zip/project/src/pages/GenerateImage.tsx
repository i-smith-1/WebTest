import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Layout } from '../components/Layout';
import {
  Image as ImageIcon,
  Loader2,
  AlertCircle,
  CheckCircle,
  Download,
  RefreshCw,
} from 'lucide-react';
import { getUserContent } from '../services/contentService';
import { supabase } from '../lib/supabase';
import type { GeneratedContent } from '../types/database';

export function GenerateImage() {
  const { user } = useAuth();
  const [contentList, setContentList] = useState<GeneratedContent[]>([]);
  const [selectedContent, setSelectedContent] = useState<string>('');
  const [customPrompt, setCustomPrompt] = useState('');
  const [mode, setMode] = useState<'existing' | 'custom'>('existing');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingContent, setLoadingContent] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    if (user) {
      loadContent();
    }
  }, [user]);

  const loadContent = async () => {
    if (!user) return;
    try {
      const data = await getUserContent(user.id);
      setContentList(data);
    } catch (err) {
      console.error('Error loading content:', err);
    } finally {
      setLoadingContent(false);
    }
  };

  const getImagePrompt = () => {
    if (mode === 'custom') {
      return customPrompt;
    }

    const content = contentList.find((c) => c.id === selectedContent);
    return content?.image_prompt || '';
  };

  const handleGenerate = async () => {
    setError('');
    setSuccess('');

    const prompt = getImagePrompt();
    if (!prompt) {
      setError('Please select content or enter a custom prompt');
      return;
    }

    setLoading(true);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-instagram-content`;
      const headers = {
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      };

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          niche: 'General',
          goal: 'Visual content',
          tone: 'Professional',
          postType: 'Feed Post',
          generateImage: true,
          generateVideo: false,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate image');
      }

      const data = await response.json();

      if (data.imageUrl) {
        setGeneratedImage(data.imageUrl);

        if (mode === 'existing' && selectedContent) {
          const { error: updateError } = await supabase
            .from('generated_content')
            .update({ image_url: data.imageUrl, media_type: 'image' })
            .eq('id', selectedContent);

          if (updateError) throw updateError;

          await loadContent();
          setSuccess('Image generated and saved successfully!');
        } else {
          setSuccess('Image generated successfully!');
        }
      } else {
        throw new Error('No image URL returned');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate image');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async () => {
    if (!generatedImage) return;

    try {
      const response = await fetch(generatedImage);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `instagram-image-${Date.now()}.png`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err) {
      setError('Failed to download image');
    }
  };

  const selectedContentData = contentList.find((c) => c.id === selectedContent);

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Generate AI Images</h1>
          <p className="text-gray-500">
            Create stunning AI-generated images for your Instagram posts using DALL-E 3.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="bg-white rounded-2xl border border-gray-100 p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-6">Image Settings</h2>

              {error && (
                <div className="flex items-center gap-3 p-4 bg-red-50 border border-red-100 rounded-xl text-red-700 text-sm mb-6">
                  <AlertCircle className="w-5 h-5 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {success && (
                <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-100 rounded-xl text-green-700 text-sm mb-6">
                  <CheckCircle className="w-5 h-5 flex-shrink-0" />
                  <span>{success}</span>
                </div>
              )}

              <div className="space-y-5">
                <div className="flex gap-2 p-1 bg-gray-100 rounded-lg">
                  <button
                    onClick={() => setMode('existing')}
                    className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
                      mode === 'existing'
                        ? 'bg-white text-gray-900 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    Use Existing Content
                  </button>
                  <button
                    onClick={() => setMode('custom')}
                    className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
                      mode === 'custom'
                        ? 'bg-white text-gray-900 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    Custom Prompt
                  </button>
                </div>

                {mode === 'existing' ? (
                  <>
                    {loadingContent ? (
                      <div className="flex items-center justify-center py-8">
                        <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
                      </div>
                    ) : contentList.length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-gray-500 text-sm">
                          No content found. Create some content first!
                        </p>
                      </div>
                    ) : (
                      <>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Select Content
                          </label>
                          <select
                            value={selectedContent}
                            onChange={(e) => setSelectedContent(e.target.value)}
                            className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent bg-white"
                          >
                            <option value="">Choose content...</option>
                            {contentList.map((content) => (
                              <option key={content.id} value={content.id}>
                                {content.caption.substring(0, 60)}...
                              </option>
                            ))}
                          </select>
                        </div>

                        {selectedContentData && (
                          <div className="p-4 bg-gray-50 rounded-xl space-y-3">
                            <div>
                              <p className="text-xs font-medium text-gray-500 mb-1">Caption</p>
                              <p className="text-sm text-gray-700">{selectedContentData.caption}</p>
                            </div>
                            <div>
                              <p className="text-xs font-medium text-gray-500 mb-1">
                                Image Prompt
                              </p>
                              <p className="text-sm text-gray-700">
                                {selectedContentData.image_prompt}
                              </p>
                            </div>
                            {selectedContentData.image_url && (
                              <div>
                                <p className="text-xs font-medium text-teal-600 mb-1">
                                  Existing Image
                                </p>
                                <img
                                  src={selectedContentData.image_url}
                                  alt="Existing"
                                  className="w-full rounded-lg"
                                />
                              </div>
                            )}
                          </div>
                        )}
                      </>
                    )}
                  </>
                ) : (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Image Prompt
                    </label>
                    <textarea
                      value={customPrompt}
                      onChange={(e) => setCustomPrompt(e.target.value)}
                      placeholder="Describe the image you want to generate..."
                      rows={6}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent resize-none"
                    />
                    <p className="text-xs text-gray-500 mt-2">
                      Be detailed and specific for best results. Example: "A minimalist flat lay of
                      a coffee cup and laptop on a white marble desk, soft morning light, Instagram
                      aesthetic"
                    </p>
                  </div>
                )}

                <button
                  onClick={handleGenerate}
                  disabled={loading || (mode === 'existing' && !selectedContent) || (mode === 'custom' && !customPrompt)}
                  className="w-full py-3 bg-gradient-to-r from-teal-500 to-cyan-600 text-white font-semibold rounded-xl hover:from-teal-600 hover:to-cyan-700 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Generating Image...
                    </>
                  ) : (
                    <>
                      <ImageIcon className="w-5 h-5" />
                      Generate Image
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white rounded-2xl border border-gray-100 p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">Generated Image</h2>
                {generatedImage && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleGenerate}
                      disabled={loading}
                      className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                      title="Regenerate"
                    >
                      <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
                    </button>
                    <button
                      onClick={handleDownload}
                      className="flex items-center gap-2 px-4 py-2 bg-teal-50 text-teal-700 font-medium rounded-lg hover:bg-teal-100 transition-colors"
                    >
                      <Download className="w-4 h-4" />
                      Download
                    </button>
                  </div>
                )}
              </div>

              {!generatedImage ? (
                <div className="text-center py-16">
                  <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <ImageIcon className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500">
                    {mode === 'existing'
                      ? 'Select content and click Generate to create an image'
                      : 'Enter a prompt and click Generate to create an image'}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="relative rounded-xl overflow-hidden border border-gray-200">
                    <img src={generatedImage} alt="Generated" className="w-full h-auto" />
                  </div>
                  <p className="text-xs text-gray-500 text-center">
                    Image generated with DALL-E 3
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
