import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Layout } from '../components/Layout';
import {
  Sparkles,
  Calendar,
  FileText,
  Clock,
  ArrowRight,
  Loader2,
  TrendingUp,
  Image
} from 'lucide-react';
import { getUserContent } from '../services/contentService';
import { getUserScheduledPosts } from '../services/scheduleService';
import type { GeneratedContent } from '../types/database';
import type { ScheduledPostWithContent } from '../types';

export function Dashboard() {
  const { user } = useAuth();
  const [content, setContent] = useState<GeneratedContent[]>([]);
  const [scheduledPosts, setScheduledPosts] = useState<ScheduledPostWithContent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    try {
      const [contentData, scheduledData] = await Promise.all([
        getUserContent(user.id),
        getUserScheduledPosts(user.id),
      ]);
      setContent(contentData);
      setScheduledPosts(scheduledData);
    } catch (err) {
      console.error('Error loading dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  const pendingPosts = scheduledPosts.filter((p) => p.status === 'pending');
  const recentContent = content.slice(0, 3);

  const stats = [
    {
      label: 'Total Content',
      value: content.length,
      icon: FileText,
      color: 'bg-teal-500',
    },
    {
      label: 'Scheduled Posts',
      value: pendingPosts.length,
      icon: Clock,
      color: 'bg-cyan-500',
    },
    {
      label: 'This Week',
      value: pendingPosts.filter((p) => {
        const postDate = new Date(p.scheduled_date);
        const today = new Date();
        const weekFromNow = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
        return postDate >= today && postDate <= weekFromNow;
      }).length,
      icon: Calendar,
      color: 'bg-emerald-500',
    },
  ];

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="w-8 h-8 animate-spin text-teal-600" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900 mb-1">
            Welcome back{user?.user_metadata?.full_name ? `, ${user.user_metadata.full_name}` : ''}
          </h1>
          <p className="text-gray-500">{user?.email}</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {stats.map((stat) => (
            <div key={stat.label} className="bg-white rounded-2xl p-6 border border-gray-100">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-10 h-10 ${stat.color} rounded-xl flex items-center justify-center`}>
                  <stat.icon className="w-5 h-5 text-white" />
                </div>
                <TrendingUp className="w-5 h-5 text-gray-300" />
              </div>
              <p className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</p>
              <p className="text-sm text-gray-500">{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Quick Actions</h2>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <Link
                to="/create"
                className="bg-gradient-to-br from-teal-500 to-cyan-600 rounded-2xl p-6 text-white hover:scale-[1.02] transition-transform"
              >
                <Sparkles className="w-8 h-8 mb-4" />
                <h3 className="font-semibold text-lg mb-1">Generate Caption</h3>
                <p className="text-teal-100 text-sm">Create captions & hashtags</p>
              </Link>
              <Link
                to="/generate-image"
                className="bg-gradient-to-br from-cyan-500 to-blue-600 rounded-2xl p-6 text-white hover:scale-[1.02] transition-transform"
              >
                <Image className="w-8 h-8 mb-4" />
                <h3 className="font-semibold text-lg mb-1">Generate Image</h3>
                <p className="text-cyan-100 text-sm">Create AI images with DALL-E</p>
              </Link>
            </div>
          </div>

          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Upcoming Posts</h2>
              <Link
                to="/schedule"
                className="text-sm text-teal-600 hover:text-teal-700 flex items-center gap-1"
              >
                View all <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
            <div className="bg-white rounded-2xl border border-gray-100 divide-y divide-gray-100 overflow-hidden">
              {pendingPosts.length === 0 ? (
                <div className="p-6 text-center">
                  <Calendar className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500 text-sm">No scheduled posts yet</p>
                  <Link to="/create" className="text-teal-600 text-sm hover:underline">
                    Create your first post
                  </Link>
                </div>
              ) : (
                pendingPosts.slice(0, 3).map((post) => (
                  <div key={post.id} className="p-4 hover:bg-gray-50">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 bg-teal-50 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Calendar className="w-5 h-5 text-teal-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-gray-900 font-medium truncate">
                          {post.generated_content.caption.substring(0, 50)}...
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          {new Date(post.scheduled_date).toLocaleDateString('en-US', {
                            weekday: 'short',
                            month: 'short',
                            day: 'numeric',
                          })}{' '}
                          at {post.scheduled_time.substring(0, 5)}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {recentContent.length > 0 && (
          <div className="mt-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Recent Content</h2>
              <Link
                to="/create"
                className="text-sm text-teal-600 hover:text-teal-700 flex items-center gap-1"
              >
                Create new <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {recentContent.map((item) => (
                <div key={item.id} className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-lg transition-shadow">
                  {item.image_url && (
                    <div className="aspect-square w-full overflow-hidden bg-gray-100">
                      <img
                        src={item.image_url}
                        alt="Generated content"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <div className="p-5">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="px-2 py-1 bg-teal-50 text-teal-700 text-xs font-medium rounded-full">
                        {item.post_type}
                      </span>
                      <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs font-medium rounded-full">
                        {item.tone}
                      </span>
                    </div>
                    <p className="text-sm text-gray-900 line-clamp-3 mb-3">{item.caption}</p>
                    <p className="text-xs text-gray-400">
                      {new Date(item.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
