export { Home } from './Home';
export { Login } from './Login';
export { Register } from './Register';
export { Dashboard } from './Dashboard';
export { CreateContent } from './CreateContent';
export { GenerateImage } from './GenerateImage';
export { Schedule } from './Schedule';
export { Instagram } from './Instagram';
