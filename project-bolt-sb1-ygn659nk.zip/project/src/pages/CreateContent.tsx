import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Layout } from '../components/Layout';
import { Sparkles, Loader2, Copy, Check, Save, Image as ImageIcon, Hash, FileText, Wand2, TrendingUp } from 'lucide-react';
import { generateContent, saveGeneratedContent } from '../services/contentService';
import type { ContentGenerationInput, GeneratedContentResult } from '../types';

const niches = [
  'Fashion & Style',
  'Fitness & Health',
  'Food & Cooking',
  'Travel & Adventure',
  'Business & Entrepreneurship',
  'Technology & Gadgets',
  'Beauty & Skincare',
  'Photography',
  'Art & Design',
  'Education & Learning',
  'Lifestyle',
  'Entertainment',
];

const goals = [
  'Increase engagement',
  'Grow followers',
  'Drive website traffic',
  'Build brand awareness',
  'Educate audience',
  'Sell products/services',
  'Build community',
  'Inspire & motivate',
];

const tones = [
  'Professional',
  'Casual & Friendly',
  'Inspirational',
  'Humorous',
  'Educational',
  'Conversational',
  'Bold & Confident',
  'Warm & Personal',
];

const postTypes = [
  'Feed Post',
  'Carousel',
  'Reel',
  'Story',
  'IGTV',
  'Quote Post',
  'Behind the Scenes',
  'Tutorial',
  'Product Showcase',
  'User Generated Content',
];

const fallbackMessages = [
  {
    caption: "Living my best life, one post at a time! What's inspiring you today? Drop your thoughts below and let's connect with our amazing community. Remember, every moment is an opportunity to share your unique story with the world!",
    hashtags: "#instagram #contentcreator #socialmedia #digitalmarketing #engagement #lifestyle #inspiration #community #viral #trending #growth #influence #creative #authentic #success",
    imagePrompt: "Professional social media content creation workspace with modern aesthetic, laptop and coffee on clean desk, natural lighting, inspirational atmosphere"
  },
  {
    caption: "Just another day chasing dreams and making things happen! Who else is ready to conquer their goals this week? Tag someone who motivates you to be your best self. Together we grow stronger!",
    hashtags: "#motivation #goals #success #hustle #entrepreneur #mindset #positivevibes #inspiration #grind #productivity #ambitious #dreambig #nevergiveup #winner #focused",
    imagePrompt: "Motivational workspace setup with journal, morning coffee, and sunrise view through window, clean modern aesthetic with warm golden lighting"
  },
  {
    caption: "Starting the day with good vibes and even better energy! What's your secret to staying positive? Share your tips below and let's inspire each other. Your vibe attracts your tribe!",
    hashtags: "#goodvibes #positivity #energy #wellness #selfcare #mindfulness #happiness #grateful #blessed #morningmotivation #dailyinspiration #lifestyle #balance #peace #joy",
    imagePrompt: "Peaceful morning scene with yoga mat, plants, natural light streaming in, minimalist aesthetic, serene atmosphere with soft colors"
  },
  {
    caption: "Behind every success is a story of perseverance and passion. Today I'm celebrating the small wins that lead to big victories! What win are you celebrating today? Drop it in the comments!",
    hashtags: "#success #passion #perseverance #celebration #wins #progress #journey #growth #achievement #dedication #committed #excellence #winning #champion #unstoppable",
    imagePrompt: "Celebratory flat lay with confetti, champagne glass, journal with handwritten goals, elegant modern aesthetic with gold accents"
  },
  {
    caption: "Creating my own sunshine on this beautiful day! Life is all about perspective and choosing to see the bright side. What are you grateful for right now? Let's spread some positivity together!",
    hashtags: "#gratitude #positiveenergy #sunshine #blessed #thankful #perspective #optimism #happiness #joyful #appreciate #goodlife #smile #choosehappy #radiatepositivity #lovinglife",
    imagePrompt: "Bright and airy aesthetic with flowers, sunny window, natural elements, soft pastel colors, fresh and uplifting atmosphere"
  }
];

export function CreateContent() {
  const { user } = useAuth();
  const [input, setInput] = useState<ContentGenerationInput>({
    niche: '',
    goal: '',
    tone: '',
    postType: '',
    generateImage: true,
    generateVideo: false,
  });
  const [result, setResult] = useState<GeneratedContentResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleInputChange = (field: keyof ContentGenerationInput, value: string | boolean) => {
    setInput((prev) => ({ ...prev, [field]: value }));
  };

  const validateInput = () => {
    return input.niche && input.goal && input.tone && input.postType;
  };

  const handleGenerate = async () => {
    if (!validateInput()) return;

    setLoading(true);
    try {
      const generatedResult = await generateContent(input);
      setResult(generatedResult);
    } catch (err) {
      console.error('Generation error:', err);
      const randomMessage = fallbackMessages[Math.floor(Math.random() * fallbackMessages.length)];
      setResult({
        caption: randomMessage.caption,
        hashtags: randomMessage.hashtags,
        imagePrompt: randomMessage.imagePrompt,
        mediaType: 'none'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!user || !result) return;

    setSaving(true);
    try {
      await saveGeneratedContent(user.id, input, result);
      setTimeout(() => setSaving(false), 1000);
    } catch (err) {
      console.error('Save error:', err);
      setSaving(false);
    }
  };

  const handleCopy = async (text: string, field: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex items-start justify-between mb-12 gap-8">
            <div className="flex-1 text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl mb-4 shadow-lg">
                <Wand2 className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-4xl font-bold text-gray-900 mb-3">Content Generator</h1>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Create engaging Instagram captions, hashtags, and image prompts in seconds
              </p>
            </div>
            <div className="flex-shrink-0 w-64">
              <div className="bg-gradient-to-br from-orange-50 to-pink-50 rounded-2xl shadow-lg border border-orange-100 p-5">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-7 h-7 bg-gradient-to-br from-orange-500 to-pink-500 rounded-lg flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 text-white" />
                  </div>
                  <h3 className="text-base font-bold text-gray-900">Trending Now</h3>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 px-3 py-2 bg-white rounded-lg hover:shadow-md transition-shadow cursor-pointer">
                    <span className="text-xl">🍕</span>
                    <span className="text-xs font-medium text-gray-700">Pizza Night Out</span>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-2 bg-white rounded-lg hover:shadow-md transition-shadow cursor-pointer">
                    <span className="text-xl">🍽️</span>
                    <span className="text-xs font-medium text-gray-700">Dinner</span>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-2 bg-white rounded-lg hover:shadow-md transition-shadow cursor-pointer">
                    <span className="text-xl">🥧</span>
                    <span className="text-xs font-medium text-gray-700">Pie</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-5 gap-8">
            <div className="lg:col-span-2">
              <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8 sticky top-24">
                <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-blue-500" />
                  Setup Your Content
                </h2>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      Select Your Niche
                    </label>
                    <select
                      value={input.niche}
                      onChange={(e) => handleInputChange('niche', e.target.value)}
                      className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-50 hover:bg-white transition-colors text-gray-900 font-medium"
                    >
                      <option value="">Choose a niche...</option>
                      {niches.map((niche) => (
                        <option key={niche} value={niche}>
                          {niche}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      Content Goal
                    </label>
                    <select
                      value={input.goal}
                      onChange={(e) => handleInputChange('goal', e.target.value)}
                      className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-50 hover:bg-white transition-colors text-gray-900 font-medium"
                    >
                      <option value="">Choose your goal...</option>
                      {goals.map((goal) => (
                        <option key={goal} value={goal}>
                          {goal}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      Tone of Voice
                    </label>
                    <select
                      value={input.tone}
                      onChange={(e) => handleInputChange('tone', e.target.value)}
                      className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-50 hover:bg-white transition-colors text-gray-900 font-medium"
                    >
                      <option value="">Choose tone...</option>
                      {tones.map((tone) => (
                        <option key={tone} value={tone}>
                          {tone}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-3">
                      Post Type
                    </label>
                    <select
                      value={input.postType}
                      onChange={(e) => handleInputChange('postType', e.target.value)}
                      className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-gray-50 hover:bg-white transition-colors text-gray-900 font-medium"
                    >
                      <option value="">Choose post type...</option>
                      {postTypes.map((type) => (
                        <option key={type} value={type}>
                          {type}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="pt-4">
                    <button
                      onClick={handleGenerate}
                      disabled={loading || !validateInput()}
                      className="w-full py-4 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-bold rounded-xl hover:from-blue-600 hover:to-cyan-600 focus:outline-none focus:ring-4 focus:ring-blue-300 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-3 text-lg"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="w-6 h-6 animate-spin" />
                          Generating Magic...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-6 h-6" />
                          Generate Content
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-3">
              {!result ? (
                <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-16 text-center">
                  <div className="w-24 h-24 bg-gradient-to-br from-gray-100 to-gray-200 rounded-3xl flex items-center justify-center mx-auto mb-6">
                    <FileText className="w-12 h-12 text-gray-400" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">Ready to Create?</h3>
                  <p className="text-gray-500 text-lg max-w-md mx-auto">
                    Select your preferences and click generate to create amazing Instagram content
                  </p>
                </div>
              ) : (
                <div className="space-y-6">
                  {result.imageUrl && (
                    <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
                      <img
                        src={result.imageUrl}
                        alt="Generated content"
                        className="w-full h-96 object-cover"
                      />
                    </div>
                  )}

                  <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8">
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
                          <FileText className="w-5 h-5 text-white" />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900">Caption</h3>
                      </div>
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => handleCopy(result.caption, 'caption')}
                          className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors text-sm font-medium text-gray-700"
                        >
                          {copiedField === 'caption' ? (
                            <>
                              <Check className="w-4 h-4 text-green-500" />
                              Copied!
                            </>
                          ) : (
                            <>
                              <Copy className="w-4 h-4" />
                              Copy
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                    <p className="text-gray-700 text-lg leading-relaxed whitespace-pre-wrap">
                      {result.caption}
                    </p>
                  </div>

                  <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8">
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-500 rounded-xl flex items-center justify-center">
                          <Hash className="w-5 h-5 text-white" />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900">Hashtags</h3>
                      </div>
                      <button
                        onClick={() => handleCopy(result.hashtags, 'hashtags')}
                        className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors text-sm font-medium text-gray-700"
                      >
                        {copiedField === 'hashtags' ? (
                          <>
                            <Check className="w-4 h-4 text-green-500" />
                            Copied!
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4" />
                            Copy
                          </>
                        )}
                      </button>
                    </div>
                    <p className="text-blue-600 font-medium leading-relaxed">
                      {result.hashtags}
                    </p>
                  </div>

                  {result.imagePrompt && (
                    <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8">
                      <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                            <ImageIcon className="w-5 h-5 text-white" />
                          </div>
                          <h3 className="text-xl font-bold text-gray-900">Image Prompt</h3>
                        </div>
                        <button
                          onClick={() => handleCopy(result.imagePrompt, 'imagePrompt')}
                          className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors text-sm font-medium text-gray-700"
                        >
                          {copiedField === 'imagePrompt' ? (
                            <>
                              <Check className="w-4 h-4 text-green-500" />
                              Copied!
                            </>
                          ) : (
                            <>
                              <Copy className="w-4 h-4" />
                              Copy
                            </>
                          )}
                        </button>
                      </div>
                      <p className="text-gray-700 leading-relaxed">
                        {result.imagePrompt}
                      </p>
                    </div>
                  )}

                  <div className="flex items-center gap-4">
                    <button
                      onClick={handleGenerate}
                      disabled={loading}
                      className="flex-1 py-4 bg-gradient-to-r from-gray-100 to-gray-200 text-gray-700 font-bold rounded-xl hover:from-gray-200 hover:to-gray-300 transition-all flex items-center justify-center gap-2"
                    >
                      <Sparkles className="w-5 h-5" />
                      Regenerate
                    </button>
                    <button
                      onClick={handleSave}
                      disabled={saving}
                      className="flex-1 py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-xl hover:from-green-600 hover:to-emerald-600 transition-all flex items-center justify-center gap-2 shadow-lg"
                    >
                      {saving ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="w-5 h-5" />
                          Save Content
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
