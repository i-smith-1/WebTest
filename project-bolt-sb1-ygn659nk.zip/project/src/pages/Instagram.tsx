import { useState } from 'react';
import { Layout } from '../components/Layout';
import {
  Heart,
  MessageCircle,
  Send,
  Bookmark,
  MoreHorizontal,
  Home,
  Search,
  PlusSquare,
  Film,
  User,
} from 'lucide-react';

const foodImages = [
  'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=1024',
  'https://images.pexels.com/photos/262959/pexels-photo-262959.jpeg?auto=compress&cs=tinysrgb&w=1024',
  'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=1024',
];

const posts = [
  {
    id: 1,
    image: foodImages[0],
    likes: 1247,
    caption: 'Absolutely divine! The flavors in this dish are incredible. Every bite tells a story of culinary excellence. 🍽️✨ #FoodieHeaven',
    time: '2 hours ago',
  },
  {
    id: 2,
    image: foodImages[1],
    likes: 892,
    caption: 'Fresh, vibrant, and bursting with flavor! This is what food dreams are made of. The presentation alone deserves applause. 👨‍🍳🌟',
    time: '5 hours ago',
  },
  {
    id: 3,
    image: foodImages[2],
    likes: 2134,
    caption: 'Pure perfection on a plate. The chef has truly outdone themselves. This is a must-try for any food lover! 🎨🍴 #Delicious',
    time: '1 day ago',
  },
];

export function Instagram() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username && password) {
      setIsLoggedIn(true);
    }
  };

  if (!isLoggedIn) {
    return (
      <Layout>
        <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
          <div className="max-w-md w-full">
            <div className="bg-white border border-gray-300 rounded-lg p-10">
              <div className="text-center mb-8">
                <h1 className="text-4xl font-['Lobster'] mb-6">Instagram</h1>
                <p className="text-gray-500 text-sm font-semibold mb-6">
                  Sign in to see photos and videos from your friends.
                </p>
              </div>

              <form onSubmit={handleLogin} className="space-y-2">
                <input
                  type="text"
                  placeholder="Phone number, username, or email"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-sm bg-gray-50 text-xs focus:outline-none focus:border-gray-400"
                />
                <input
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-sm bg-gray-50 text-xs focus:outline-none focus:border-gray-400"
                />
                <button
                  type="submit"
                  className="w-full py-2 bg-blue-500 text-white rounded-lg font-semibold text-sm hover:bg-blue-600 transition-colors mt-3"
                >
                  Log in
                </button>
              </form>

              <div className="flex items-center my-4">
                <div className="flex-1 border-t border-gray-300"></div>
                <span className="px-4 text-gray-500 text-xs font-semibold">OR</span>
                <div className="flex-1 border-t border-gray-300"></div>
              </div>

              <button className="w-full flex items-center justify-center gap-2 text-blue-900 font-semibold text-sm">
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="#395185">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
                Log in with Facebook
              </button>

              <div className="text-center mt-4">
                <a href="#" className="text-xs text-blue-900">
                  Forgot password?
                </a>
              </div>
            </div>

            <div className="bg-white border border-gray-300 rounded-lg p-5 mt-3 text-center">
              <p className="text-sm">
                Don't have an account?{' '}
                <a href="#" className="text-blue-500 font-semibold">
                  Sign up
                </a>
              </p>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="min-h-screen bg-gray-50">
        <div className="bg-white border-b border-gray-300 sticky top-16 z-40">
          <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
            <h1 className="text-2xl font-['Lobster']">Instagram</h1>
            <div className="flex items-center gap-6">
              <Home className="w-6 h-6 cursor-pointer" />
              <Send className="w-6 h-6 cursor-pointer" />
              <PlusSquare className="w-6 h-6 cursor-pointer" />
              <Film className="w-6 h-6 cursor-pointer" />
              <User className="w-6 h-6 cursor-pointer" />
            </div>
          </div>
        </div>

        <div className="max-w-lg mx-auto py-8">
          <div className="bg-white border border-gray-300 rounded-lg mb-6 p-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 via-pink-500 to-purple-600 rounded-full flex items-center justify-center">
                <div className="w-9 h-9 bg-white rounded-full flex items-center justify-center">
                  <span className="text-xl">🍽️</span>
                </div>
              </div>
              <div className="flex-1">
                <div className="font-semibold text-sm">restaurant_reviewer</div>
                <div className="text-xs text-gray-500">Food Critic & Enthusiast</div>
              </div>
              <button className="text-blue-500 font-semibold text-sm">Follow</button>
            </div>

            <div className="mb-3">
              <div className="text-sm">
                <span className="font-semibold">2.4M</span> followers · <span className="font-semibold">1,847</span> posts
              </div>
              <p className="text-sm mt-2">
                🍴 Exploring the world one bite at a time
                <br />
                📍 Currently in New York
                <br />
                💌 DM for collabs
              </p>
            </div>
          </div>

          {posts.map((post) => (
            <div key={post.id} className="bg-white border border-gray-300 rounded-lg mb-6">
              <div className="flex items-center justify-between p-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-yellow-400 via-pink-500 to-purple-600 rounded-full flex items-center justify-center">
                    <div className="w-7 h-7 bg-white rounded-full flex items-center justify-center">
                      <span className="text-sm">🍽️</span>
                    </div>
                  </div>
                  <span className="font-semibold text-sm">restaurant_reviewer</span>
                </div>
                <MoreHorizontal className="w-5 h-5 cursor-pointer" />
              </div>

              <img src={post.image} alt="Food" className="w-full" />

              <div className="p-3">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-4">
                    <Heart className="w-6 h-6 cursor-pointer hover:text-gray-500" />
                    <MessageCircle className="w-6 h-6 cursor-pointer hover:text-gray-500" />
                    <Send className="w-6 h-6 cursor-pointer hover:text-gray-500" />
                  </div>
                  <Bookmark className="w-6 h-6 cursor-pointer hover:text-gray-500" />
                </div>

                <div className="font-semibold text-sm mb-2">{post.likes.toLocaleString()} likes</div>

                <div className="text-sm">
                  <span className="font-semibold">restaurant_reviewer</span> {post.caption}
                </div>

                <div className="text-gray-500 text-xs mt-2">{post.time}</div>
              </div>

              <div className="border-t border-gray-300 p-3">
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    placeholder="Add a comment..."
                    className="flex-1 text-sm focus:outline-none"
                  />
                  <button className="text-blue-500 font-semibold text-sm">Post</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
}
