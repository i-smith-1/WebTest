import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const pizzaImages = [
  "https://images.pexels.com/photos/1566837/pexels-photo-1566837.jpeg?auto=compress&cs=tinysrgb&w=1024",
  "https://images.pexels.com/photos/315755/pexels-photo-315755.jpeg?auto=compress&cs=tinysrgb&w=1024",
  "https://images.pexels.com/photos/1146760/pexels-photo-1146760.jpeg?auto=compress&cs=tinysrgb&w=1024",
  "https://images.pexels.com/photos/2147491/pexels-photo-2147491.jpeg?auto=compress&cs=tinysrgb&w=1024",
  "https://images.pexels.com/photos/825661/pexels-photo-825661.jpeg?auto=compress&cs=tinysrgb&w=1024"
];

interface ContentInput {
  niche: string;
  goal: string;
  tone: string;
  postType: string;
  generateImage?: boolean;
  generateVideo?: boolean;
}

interface GeneratedContent {
  caption: string;
  hashtags: string;
  imagePrompt: string;
  imageUrl?: string;
  videoUrl?: string;
  mediaType?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { niche, goal, tone, postType, generateImage = true }: ContentInput = await req.json();

    if (!niche || !goal || !tone || !postType) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const content = generateFallbackContent(niche, goal, tone, postType);
    
    if (generateImage) {
      const randomIndex = Math.floor(Math.random() * pizzaImages.length);
      content.imageUrl = pizzaImages[randomIndex];
      content.mediaType = 'image';
    } else {
      content.mediaType = 'none';
    }

    return new Response(JSON.stringify(content), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error:", error);
    const fallbackContent = generateFallbackContent(
      "Lifestyle",
      "Increase engagement",
      "Casual & Friendly",
      "Feed Post"
    );
    return new Response(JSON.stringify(fallbackContent), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

function generateFallbackContent(
  niche: string,
  goal: string,
  tone: string,
  postType: string
): GeneratedContent {
  const captions: Record<string, string[]> = {
    "Fashion & Style": [
      "Style is a way to say who you are without having to speak. What does your style say about you? Drop a comment below! 💫",
      "Fashion fades, but style is eternal. Today's look is all about confidence and comfort. What's your go-to outfit? 👗",
      "Dressing well is a form of good manners. Elevating everyday moments one outfit at a time. Share your OOTD! ✨"
    ],
    "Fitness & Health": [
      "Progress over perfection, always. Every rep, every step, every choice counts. What's your fitness goal this week? 💪",
      "Strong body, strong mind. The only bad workout is the one that didn't happen. Let's crush those goals together! 🏋️",
      "Your body can stand almost anything. It's your mind you have to convince. Keep pushing, keep growing! 🔥"
    ],
    "Food & Cooking": [
      "Good food = good mood. There's something magical about creating delicious meals from scratch. What's cooking in your kitchen? 🍳",
      "Life's too short for boring meals! Turning everyday ingredients into extraordinary dishes. Drop your favorite recipe below! 👨‍🍳",
      "Food is not just eating energy. It's an experience. Share this with someone who loves good food! 🍽️"
    ],
    "Travel & Adventure": [
      "Adventure awaits around every corner. The world is full of beautiful places waiting to be explored. Where's your next destination? 🌍",
      "Collect moments, not things. Every journey writes a new chapter in your life story. Tag your travel buddy! ✈️",
      "Not all who wander are lost. Sometimes the best therapy is a plane ticket. Where would you go right now? 🗺️"
    ],
    "Business & Entrepreneurship": [
      "Success is built one decision at a time. Dream big, start small, act now. What bold move are you making today? 💼",
      "Your network is your net worth. Surround yourself with people who challenge and inspire you. Tag your business mentor! 📈",
      "Entrepreneurship is living a few years of your life like most people won't, so you can spend the rest like most can't. Keep grinding! 🚀"
    ],
    "Technology & Gadgets": [
      "Innovation distinguishes between a leader and a follower. What tech are you most excited about right now? 📱",
      "The future is now. Technology is best when it brings people together and solves real problems. Share your thoughts! 💻",
      "Stay curious, stay innovative. The best way to predict the future is to create it. What are you building? 🔧"
    ],
    "Beauty & Skincare": [
      "Glow from within, shine on the outside. Your skin deserves the same love and care you give others. What's your holy grail product? 💄",
      "Beauty begins the moment you decide to be yourself. Self-care isn't selfish, it's essential. Share your routine! ✨",
      "Invest in your skin. It's going to represent you for a very long time. What's your skincare secret? 🌸"
    ],
    "Photography": [
      "Every picture tells a story. The camera is an instrument that teaches people how to see. What are you capturing today? 📸",
      "Photography is the art of frozen time. Light and shadow dance together to create magic. Drop your favorite shot below! 🎨",
      "The best camera is the one that's with you. It's not about the gear, it's about the vision. Keep shooting! 📷"
    ],
    "Art & Design": [
      "Creativity takes courage. Every artist was first an amateur. Keep creating, keep growing! 🎨",
      "Art is not what you see, but what you make others see. Design is thinking made visual. Share your latest creation! 🖌️",
      "The purpose of art is washing the dust of daily life off our souls. What inspires your creativity? ✨"
    ],
    "Education & Learning": [
      "Learn something new every day. Education is the most powerful weapon to change the world. What skill are you developing? 📚",
      "The beautiful thing about learning is that no one can take it away from you. Stay curious, stay hungry! 🎓",
      "Growth mindset in action. The expert in anything was once a beginner. What are you learning today? 💡"
    ],
    "Lifestyle": [
      "Living intentionally, one moment at a time. Life isn't about finding yourself, it's about creating yourself. What brings you joy? 🌟",
      "Life is a collection of small moments. Make each one count and celebrate the little wins along the way! ✨",
      "Create a life you don't need a vacation from. Balance is not something you find, it's something you create. 🌺"
    ],
    "Entertainment": [
      "Life is better when you're laughing. Entertainment is about bringing joy and creating memories. What's making you smile today? 🎬",
      "Good vibes only! Sometimes you just need to escape into a good story. What are you watching right now? 🍿",
      "Entertainment is the shortest distance between two hearts. Share this with someone who makes you laugh! 🎭"
    ]
  };

  const hashtagsMap: Record<string, string> = {
    "Fashion & Style": "#fashion #style #ootd #fashionista #styleinspo #outfitoftheday #fashionblogger #instafashion #streetstyle #fashionstyle #stylish #fashionlover #lookoftheday #fashiongram #whatiwore #fashionaddict #styleoftheday #fashionpost #instastyle #fashiondiaries",
    "Fitness & Health": "#fitness #health #workout #gym #fitnessmotivation #healthylifestyle #fit #training #exercise #fitlife #healthyliving #gymlife #fitnessjourney #wellness #muscle #bodybuilding #personaltrainer #fitfam #gains #workoutmotivation",
    "Food & Cooking": "#food #foodie #cooking #foodporn #instafood #recipe #homemade #foodphotography #foodlover #delicious #yummy #foodblogger #chef #healthyfood #foodgasm #dinner #lunch #breakfast #tasty #foodstagram",
    "Travel & Adventure": "#travel #adventure #wanderlust #travelgram #explore #travelphotography #instatravel #traveling #travelblogger #vacation #trip #tourism #traveltheworld #traveler #backpacking #roadtrip #holiday #destinations #explorer #traveladdict",
    "Business & Entrepreneurship": "#business #entrepreneur #entrepreneurship #startup #success #motivation #smallbusiness #businessowner #entrepreneurlife #marketing #money #hustle #leadership #mindset #goals #businesstips #ceo #inspiration #growth #networking",
    "Technology & Gadgets": "#technology #tech #gadgets #innovation #digital #smartphone #electronics #software #coding #programming #techie #technews #ai #startup #developer #engineering #science #futuretech #iot #automation",
    "Beauty & Skincare": "#beauty #skincare #makeup #beautyblogger #skincareroutine #cosmetics #beautytips #glow #skincaretips #beautyhacks #makeupartist #beautycare #skinhealth #selfcare #beautyproducts #beautycommunity #naturalbeauty #beautyessentials #skincareaddict #beautylover",
    "Photography": "#photography #photooftheday #photographer #photo #photoshoot #portrait #camera #nature #art #travel #picoftheday #photographylovers #canon #nikon #streetphotography #landscape #portraitphotography #photographyislife #photographyisart #instaphoto",
    "Art & Design": "#art #design #artist #artwork #creative #drawing #illustration #graphicdesign #digitalart #painting #artoftheday #creativity #artistsoninstagram #designer #artsy #sketch #artlovers #contemporaryart #visualart #artgallery",
    "Education & Learning": "#education #learning #knowledge #study #school #teacher #student #teaching #learn #educational #motivation #university #college #skills #onlinelearning #elearning #studygram #educationmatters #studymotivation #learnmore",
    "Lifestyle": "#lifestyle #life #love #happy #instagood #motivation #inspiration #goals #positivevibes #mindfulness #happiness #livingmybestlife #dailylife #lifestyleblogger #wellness #selfcare #goodvibes #lifequotes #mindset #blessed",
    "Entertainment": "#entertainment #fun #music #movies #comedy #viral #trending #celebrity #show #tv #hollywood #film #actor #actress #singer #concert #netflix #streaming #popculture #entertainmentnews"
  };

  const imagePrompts: Record<string, string[]> = {
    "Fashion & Style": [
      "Stylish person in modern urban setting wearing contemporary fashion with soft natural lighting and editorial photography style",
      "Flat lay of trendy outfit pieces on marble surface with accessories arranged aesthetically in morning light",
      "Street style fashion moment in city setting with candid pose and golden hour lighting"
    ],
    "Fitness & Health": [
      "Athletic person mid-workout in modern gym with dynamic pose and dramatic lighting",
      "Healthy meal prep scene with colorful vegetables and proteins in bright natural lighting",
      "Outdoor fitness scene in nature with person doing yoga at sunrise"
    ],
    "Food & Cooking": [
      "Beautifully plated gourmet dish from above with restaurant quality presentation and warm lighting",
      "Cooking action shot in rustic kitchen with steam rising and fresh ingredients visible",
      "Artisanal bread close-up in bakery setting with soft natural light and texture details"
    ],
    "Travel & Adventure": [
      "Breathtaking landscape vista with lone traveler and epic scenery in golden hour lighting",
      "Charming European street scene with local cafe and authentic cultural atmosphere",
      "Beach sunset with silhouette figure in tropical paradise setting"
    ],
    "Business & Entrepreneurship": [
      "Modern office workspace with laptop and coffee in clean minimalist design with natural light",
      "Professional team meeting in contemporary space with collaborative energy",
      "Entrepreneur working in creative space with focused expression and modern equipment"
    ],
    "Technology & Gadgets": [
      "Sleek tech product on minimalist surface with dramatic lighting",
      "Person using cutting-edge technology in modern setting with futuristic vibes",
      "Close-up of innovative gadget details with precision engineering visible"
    ],
    "Beauty & Skincare": [
      "Elegant skincare products arrangement on marble surface with soft lighting",
      "Close-up portrait with dewy glowing skin and soft diffused lighting",
      "Beauty routine flat lay with products and flowers in pastel tones"
    ],
    "Photography": [
      "Photographer at work in golden hour light with camera in hand",
      "Camera equipment flat lay with vintage and modern gear",
      "Stunning landscape being photographed with tripod setup and dramatic sky"
    ],
    "Art & Design": [
      "Artist workspace with creative materials and paint splashes",
      "Digital designer working on tablet with creative software visible",
      "Abstract art piece close-up showing texture and color"
    ],
    "Education & Learning": [
      "Student studying in cozy library setting with books and warm lighting",
      "Online learning setup with laptop and notepad in organized desk",
      "Teacher engaging with students in collaborative learning moment"
    ],
    "Lifestyle": [
      "Cozy home moment with coffee and book in soft natural window light",
      "Morning routine scene with plants and sunlight in peaceful atmosphere",
      "Friends gathering in stylish space with candid happy moment"
    ],
    "Entertainment": [
      "Concert atmosphere with dramatic lighting and crowd energy visible",
      "Movie night cozy setup with popcorn and ambient lighting",
      "Behind-the-scenes creative production moment with film equipment"
    ]
  };

  const nicheKey = Object.keys(captions).find(key =>
    niche.toLowerCase().includes(key.toLowerCase()) || key.toLowerCase().includes(niche.toLowerCase())
  ) || "Lifestyle";

  const captionList = captions[nicheKey] || captions["Lifestyle"];
  const hashtags = hashtagsMap[nicheKey] || hashtagsMap["Lifestyle"];
  const imagePromptList = imagePrompts[nicheKey] || imagePrompts["Lifestyle"];

  const randomIndex = Math.floor(Math.random() * captionList.length);

  let selectedCaption = captionList[randomIndex];

  if (tone.toLowerCase().includes("humor")) {
    selectedCaption = selectedCaption.replace(/\.(?=[^.]*$)/, "! 😄");
  } else if (tone.toLowerCase().includes("professional")) {
    selectedCaption = selectedCaption.replace(/\?/g, ".");
  } else if (tone.toLowerCase().includes("inspirational")) {
    selectedCaption = selectedCaption + " ✨";
  }

  return {
    caption: selectedCaption,
    hashtags: hashtags,
    imagePrompt: imagePromptList[randomIndex] + `, optimized for Instagram ${postType.toLowerCase()}, ${tone.toLowerCase()} mood, high engagement visual`,
    mediaType: 'none'
  };
}