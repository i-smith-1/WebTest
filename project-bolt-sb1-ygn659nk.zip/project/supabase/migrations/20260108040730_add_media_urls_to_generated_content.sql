/*
  # Add Media URLs to Generated Content

  1. Changes
    - Add `image_url` column to `generated_content` table to store DALL-E generated image URLs
    - Add `video_url` column to `generated_content` table for future video generation support
    - Add `media_type` column to track what type of media was generated (image, video, both, none)
    
  2. Notes
    - Uses IF NOT EXISTS pattern for safe migration
    - Default values ensure backward compatibility with existing records
    - media_type defaults to 'none' for existing records that don't have generated media
*/

-- Add image_url column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'generated_content' AND column_name = 'image_url'
  ) THEN
    ALTER TABLE generated_content ADD COLUMN image_url text DEFAULT '';
  END IF;
END $$;

-- Add video_url column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'generated_content' AND column_name = 'video_url'
  ) THEN
    ALTER TABLE generated_content ADD COLUMN video_url text DEFAULT '';
  END IF;
END $$;

-- Add media_type column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'generated_content' AND column_name = 'media_type'
  ) THEN
    ALTER TABLE generated_content ADD COLUMN media_type text DEFAULT 'none';
  END IF;
END $$;